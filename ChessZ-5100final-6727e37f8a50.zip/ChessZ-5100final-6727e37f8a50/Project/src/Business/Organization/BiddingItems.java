/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

/**
 *
 * @author 111
 */
public class BiddingItems extends BuyerOrganization{
    private String BiddingItemName;
    private String BiddingItemNumber;

    public String getBiddingItemName() {
        return BiddingItemName;
    }

    public void setBiddingItemName(String BiddingItemName) {
        this.BiddingItemName = BiddingItemName;
    }

    public String getBiddingItemNumber() {
        return BiddingItemNumber;
    }

    public void setBiddingItemNumber(String BiddingItemNumber) {
        this.BiddingItemNumber = BiddingItemNumber;
    }
    

    
    
    
}
